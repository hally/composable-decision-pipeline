def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Composable Decision Pipeline is alive."
    }
